#include "rm_referee.h"
#include "string.h"
#include "crc_ref.h"
#include "bsp_usart.h"
#include "task.h"
#include "daemon.h"
// #include "bsp_log.h"
#include "cmsis_os.h"
#include <stdint.h>

#define RE_RX_BUFFER_SIZE 255u // 裁判系统接收缓冲区大小

static USARTInstance *referee_usart_instance; // 裁判系统串口实例
static DaemonInstance *referee_daemon;		  // 裁判系统守护进程
static referee_info_t referee_info;			  // 裁判系统数据

/**
 * @brief  读取裁判数据,中断中读取保证速度
 * @param  buff: 读取到的裁判系统原始数据
 * @retval 是否对正误判断做处理
 * @attention  在此判断帧头和CRC校验,无误再写入数据，不重复判断帧头
 */
uint8_t JudgeReadData(uint8_t *buff)
{
    if (buff == NULL) 
    {
        return 0;
    }
    // 写入帧头数据
    memcpy(&referee_info.FrameHeader, buff, LEN_HEADER);
    // 判断帧头起始字节
    if (buff[SOF] != REFEREE_SOF) 
    {
        return 0;
    }
    // 帧头CRC8校验
    if (Verify_CRC8_Check_Sum(buff, LEN_HEADER) != TRUE) {
        return 0;
    }
    // 计算完整帧长度
    uint16_t judge_length = buff[DATA_LENGTH] + LEN_HEADER + LEN_CMDID + LEN_TAIL;
    // 帧尾CRC16校验
    if (Verify_CRC16_Check_Sum(buff, judge_length) != TRUE) 
    {
        return 0;
    }
    // 提取命令ID
    referee_info.CmdID = (buff[6] << 8 | buff[5]);

    // 第8个字节开始才是数据 data=7
    switch (referee_info.CmdID)
    {
        case ID_game_state: // 0x0001
            memcpy(&referee_info.GameState, (buff + DATA_Offset), LEN_game_state);
            break;
        case ID_game_result: // 0x0002
            memcpy(&referee_info.GameResult, (buff + DATA_Offset), LEN_game_result);
            break;
        case ID_game_robot_survivors: // 0x0003
            memcpy(&referee_info.GameRobotHP, (buff + DATA_Offset), LEN_game_robot_HP);
            break;
        case ID_event_data: // 0x0101
            memcpy(&referee_info.EventData, (buff + DATA_Offset), LEN_event_data);
            break;
        case ID_game_robot_state: // 0x0201
            memcpy(&referee_info.GameRobotState, (buff + DATA_Offset), LEN_game_robot_state);
            break;
        case ID_power_heat_data: // 0x0202
            memcpy(&referee_info.PowerHeatData, (buff + DATA_Offset), LEN_power_heat_data);
            break;
        case ID_game_robot_pos: // 0x0203
            memcpy(&referee_info.GameRobotPos, (buff + DATA_Offset), LEN_game_robot_pos);
            break;
        case ID_buff_musk: // 0x0204
            memcpy(&referee_info.BuffMusk, (buff + DATA_Offset), LEN_buff_musk);
            break;

        case ID_robot_hurt: // 0x0206
            memcpy(&referee_info.RobotHurt, (buff + DATA_Offset), LEN_robot_hurt);
            break;
        case ID_shoot_data: // 0x0207
            memcpy(&referee_info.ShootData, (buff + DATA_Offset), LEN_shoot_data);
            break;
    }
    return 1;
}



/* 裁判系统通信初始化 */
referee_info_t *RefereeInit(UART_HandleTypeDef *referee_usart_handle)
{
	USART_Init_Config_s conf;
	conf.usart_handle = referee_usart_handle;
	conf.recv_buff_size = RE_RX_BUFFER_SIZE; // mx 255(u8)
	referee_usart_instance = USARTRegister(&conf);

	// Daemon_Init_Config_s daemon_conf = {
	// 	.callback = RefereeLostCallback,
	// 	.owner_id = referee_usart_instance,
	// 	.reload_count = 30, // 0.3s没有收到数据,则认为丢失,重启串口接收
	// };
	// referee_daemon = DaemonRegister(&daemon_conf);

	return &referee_info;
}

USARTInstance * return_referee_usart_instance()
{
    return referee_usart_instance;
}
/**
 * @brief 裁判系统数据发送函数
 * @param
 */
void RefereeSend(uint8_t *send, uint16_t tx_len)
{
	USARTSend(referee_usart_instance, send, tx_len, USART_TRANSFER_DMA);
	osDelay(115);
}
